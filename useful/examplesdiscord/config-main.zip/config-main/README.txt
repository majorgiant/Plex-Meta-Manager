Movies
	Best Of
		- Top 10 Pirated
		- Top 50 Highest Grossing
		- Top Grossing Annually
		- 1001 Movies You Must See Before You Die
		- Criterion Collection
	Custom: Combination of lists for niche topics 		#AwesomeAustin
		- Conspiracy
		- Crime
		- Dark Comedy
		- Dystopian
		- Football
		- IMAX
		- Inspirational
		- Mind-Bend
		- Natural Disaster
		- Pandemic
		- Parody
		- Prison
		- Seductive
		- Space
		- Spy
		- Stand-Up Comedy
		- Sword & Sorcery
		- Time Travel
		- True Story
		- Unexpectedly Amazing
		- Video Game
		- Witch
	Oscars: Expanded Categories
		- Best Actor/Actress
		- Best Supporting Actor/Actress
		- Best Documentary
		- Best Cinematography
		- Best Film Editing
		- Best Sound
		- Best Original/Adapted Screenplay
		- Best Original Motion Picture
		- Best Visual Effects
	Rotten Tomatoes:					#AwesomeAustin
		- Best of 2014-2021
		- Best All-Time, Rom Com, and Horror
	Holidays: Never Hidden					#Magic815
		- Christmas
		- Easter
		- Halloween
		- Independence Day
		- New Year's Eve
		- St. Patrick's Day
		- Thanksgiving 		
	People:							
		- 500+ Actors, Directors and Producers
	Sequels:
		- 200+ Movie Franchise Collections

TV Shows
	Collections:						#SiskoUrso
		- Attenborough
		- Battlestar Galactica
		- C.S.I
		- Law & Order
		- Marvel Television
		- Narcos
		- NCIS
		- Star Trek
		- Stargatte
		- Star Wars
		- The Twilight Zone
		- The Walking Dead
		- The X-Files		
	Kids Collections:					#Saturday Morning Collections by JJJonesJr33
		- ABC Kids				
		- Cartoon Cartoons
		- Disney Afternoon
		- Disney's One Saturday Morning
		- Disney's One Too
		- Fox Kids
		- SNICK
		- UPN Kids
		- Kids' WB

Most posters are linked through Github.

Credits are numerous and not limited to but include: 
				- AwesomeAustin
				- meisnate12
				- ICHIMOKU
				- SiskoUrso
				- YozoraXCII
				- Frexe
				- Glastil
				- JJJonesJr33
